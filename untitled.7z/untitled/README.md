# Korge Hello World and Template

This is a Hello World and Template for the KorGe game engine. Using gradle with kotlin-dsl.
You can open this project in IntelliJ IDEA by opening the folder or the build.gradle.kts file.

You can find this template at GitHub: <https://github.com/korlibs/korge-hello-world>


You can find the KorGE documentation here: <https://docs.korge.org/korge/>
