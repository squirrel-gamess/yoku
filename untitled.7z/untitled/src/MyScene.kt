import korlibs.event.Key
import korlibs.image.format.readBitmap
import korlibs.io.file.std.resourcesVfs
import korlibs.korge.ldtk.view.LDTKLevelView
import korlibs.korge.ldtk.view.readLDTKWorld
import korlibs.korge.scene.*
import korlibs.korge.view.*
import korlibs.time.seconds

class MyScene : Scene() {
    override suspend fun SContainer.sceneMain() {
        val world = KR.ldtk.casa.__file.readLDTKWorld()


        LDTKLevelView(world.levels.first()).addTo(this).apply {
            scale = 2.0
        }



        val spritemap = resourcesVfs["MainSheet.png"].readBitmap().toBMP32()



        val frameWidth = 32
        val frameHeight = 32




        val animationFrente = SpriteAnimation(
            spritemap,
            spriteWidth = frameWidth,
            spriteHeight = frameHeight,
            columns = 8,
            rows = 1
        )

        val animationLado = SpriteAnimation(
            spritemap,
            spriteWidth = frameWidth,
            spriteHeight = frameHeight,
            columns = 8,
            rows = 1,
            marginLeft = 0,
            marginTop = frameHeight
        )

        val image = sprite(animationFrente) {
            position(256, 256)
            scale = 4.0
            smoothing = false
        }


        addUpdater {
            var isMoving = false

            if (input.keys[Key.LEFT] || input.keys[Key.A]) {
                image.playAnimationLooped(animationLado, spriteDisplayTime = 0.07.seconds)
                image.position(image.x - 4, image.y)
                image.scaleX = -4.0 // Virar horizontalmente
                isMoving = true
            }

            if (input.keys[Key.RIGHT] || input.keys[Key.D]) {
                image.playAnimationLooped(animationLado, spriteDisplayTime = 0.07.seconds)
                image.position(image.x + 4, image.y)
                image.scaleX = 4.0 // Garantir orientação normal
                isMoving = true
            }

            if (input.keys[Key.UP] || input.keys[Key.W]) {
                image.playAnimationLooped(animationFrente, spriteDisplayTime = 0.07.seconds)
                image.position(image.x, image.y - 4)
                isMoving = true
            }

            if (input.keys[Key.DOWN] || input.keys[Key.S]) {
                image.playAnimationLooped(animationFrente, spriteDisplayTime = 0.07.seconds)
                image.position(image.x, image.y + 4)
                isMoving = true
            }

            if (!isMoving) {
                // Só pare a animação se nenhuma tecla estiver pressionada
                image.stopAnimation()
                image.setFrame(0)
            }
        }
    }
}
